# How to contribute #

## Reporting issues ##

The ExoPlayer project is now developed as part of the
[AndroidX Media](https://github.com/androidx/media/blob/release/CONTRIBUTING.md)
project. Please use that project to file bugs, feature requests, questions and
pull requests.
