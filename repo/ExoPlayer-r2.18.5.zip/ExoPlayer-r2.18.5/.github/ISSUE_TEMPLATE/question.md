---
name: Question
about: Issue template for a question.
title: ''
labels: question, needs triage
assignees: ''
---

**Please do not file new issues in this repository.**

All new questions should be filed in the
[Media3 issue tracker](https://github.com/androidx/media/issues/new?template=question.md).

We will continue to update and reply to existing issues in this repository and
will keep existing feature requests active.
