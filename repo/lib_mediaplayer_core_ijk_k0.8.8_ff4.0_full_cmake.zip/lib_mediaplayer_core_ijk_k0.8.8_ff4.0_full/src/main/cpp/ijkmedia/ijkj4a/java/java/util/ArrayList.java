package ijkmedia.ijkj4a.java.java.util;

@SimpleCClassName
public class ArrayList {
    public ArrayList();
    boolean add(Object object);
}
