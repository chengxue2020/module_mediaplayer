# Extensions Demo #

A demo app that shows how to use the ExoPlayer extensions in your app.

The demo app depends on the VP9, Flac and Opus extensions being configured and
built correctly.
