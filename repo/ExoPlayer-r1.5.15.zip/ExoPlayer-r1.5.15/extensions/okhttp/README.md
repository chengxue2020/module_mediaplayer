# ExoPlayer OkHttp Extension #

## Description ##

The OkHttp Extension is an [HttpDataSource][] implementation using Square's
[OkHttp][].

[HttpDataSource]: https://google.github.io/ExoPlayer/doc/reference/com/google/android/exoplayer/upstream/HttpDataSource.html
[OkHttp]: https://square.github.io/okhttp/
