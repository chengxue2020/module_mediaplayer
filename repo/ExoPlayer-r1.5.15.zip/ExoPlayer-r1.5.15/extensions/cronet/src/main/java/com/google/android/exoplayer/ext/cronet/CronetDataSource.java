/*
 * Copyright (C) 2016 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.android.exoplayer.ext.cronet;

import android.os.ConditionVariable;
import android.text.TextUtils;
import android.util.Log;
import com.google.android.exoplayer.C;
import com.google.android.exoplayer.upstream.DataSpec;
import com.google.android.exoplayer.upstream.HttpDataSource;
import com.google.android.exoplayer.upstream.TransferListener;
import com.google.android.exoplayer.util.Assertions;
import com.google.android.exoplayer.util.Clock;
import com.google.android.exoplayer.util.Predicate;
import com.google.android.exoplayer.util.SystemClock;
import java.io.IOException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.Executor;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.chromium.net.CronetEngine;
import org.chromium.net.CronetException;
import org.chromium.net.NetworkException;
import org.chromium.net.UrlRequest;
import org.chromium.net.UrlRequest.Status;
import org.chromium.net.UrlResponseInfo;

/**
 * DataSource without intermediate buffer based on Cronet API set using UrlRequest.
 * <p>This class's methods are organized in the sequence of expected calls.
 */
public class CronetDataSource extends UrlRequest.Callback implements HttpDataSource {

  /**
   * Thrown when an error is encountered when trying to open a {@link CronetDataSource}.
   */
  public static final class OpenException extends HttpDataSourceException {

    /**
     * Returns the status of the connection establishment at the moment when the error occurred, as
     * defined by {@link UrlRequest.Status}.
     */
    public final int cronetConnectionStatus;

    public OpenException(IOException cause, DataSpec dataSpec, int cronetConnectionStatus) {
      super(cause, dataSpec, TYPE_OPEN);
      this.cronetConnectionStatus = cronetConnectionStatus;
    }

    public OpenException(String errorMessage, DataSpec dataSpec, int cronetConnectionStatus) {
      super(errorMessage, dataSpec, TYPE_OPEN);
      this.cronetConnectionStatus = cronetConnectionStatus;
    }

  }

  /**
   * The default connection timeout, in milliseconds.
   */
  public static final int DEFAULT_CONNECT_TIMEOUT_MILLIS = 8 * 1000;
  /**
   * The default read timeout, in milliseconds.
   */
  public static final int DEFAULT_READ_TIMEOUT_MILLIS = 8 * 1000;

  private static final String TAG = "CronetDataSource";
  private static final String CONTENT_TYPE = "Content-Type";
  private static final Pattern CONTENT_RANGE_HEADER_PATTERN =
      Pattern.compile("^bytes (\\d+)-(\\d+)/(\\d+)$");
  // The size of read buffer passed to cronet UrlRequest.read().
  private static final int READ_BUFFER_SIZE_BYTES = 32 * 1024;

  private final CronetEngine cronetEngine;
  private final Executor executor;
  private final Predicate<String> contentTypePredicate;
  private final TransferListener listener;
  private final int connectTimeoutMs;
  private final int readTimeoutMs;
  private final boolean resetTimeoutOnRedirects;
  private final Map<String, String> requestProperties;
  private final ConditionVariable operation;
  private final Clock clock;

  // Accessed by the calling thread only.
  private boolean opened;
  private long bytesToSkip;
  private long bytesRemaining;

  // Written from the calling thread only. currentUrlRequest.start() calls ensure writes are visible
  // to reads made by the Cronet thread.
  private UrlRequest currentUrlRequest;
  private DataSpec currentDataSpec;

  // Reference written and read by calling thread only. Passed to Cronet thread as a local variable.
  // operation.open() calls ensure writes into the buffer are visible to reads made by the calling
  // thread.
  private ByteBuffer readBuffer;

  // Written from the Cronet thread only. operation.open() calls ensure writes are visible to reads
  // made by the calling thread.
  private UrlResponseInfo responseInfo;
  private IOException exception;
  private boolean finished;

  private volatile long currentConnectTimeoutMs;

  /**
   * @param cronetEngine A CronetEngine.
   * @param executor The {@link java.util.concurrent.Executor} that will perform the requests.
   * @param contentTypePredicate An optional {@link Predicate}. If a content type is rejected by the
   *     predicate then an {@link InvalidContentTypeException} is thrown from
   *     {@link #open(DataSpec)}.
   * @param listener An optional listener.
   */
  public CronetDataSource(CronetEngine cronetEngine, Executor executor,
      Predicate<String> contentTypePredicate, TransferListener listener) {
    this(cronetEngine, executor, contentTypePredicate, listener, DEFAULT_CONNECT_TIMEOUT_MILLIS,
        DEFAULT_READ_TIMEOUT_MILLIS, false);
  }

  /**
   * @param cronetEngine A CronetEngine.
   * @param executor The {@link java.util.concurrent.Executor} that will perform the requests.
   * @param contentTypePredicate An optional {@link Predicate}. If a content type is rejected by the
   *     predicate then an {@link InvalidContentTypeException} is thrown from
   *     {@link #open(DataSpec)}.
   * @param listener An optional listener.
   * @param connectTimeoutMs The connection timeout, in milliseconds.
   * @param readTimeoutMs The read timeout, in milliseconds.
   * @param resetTimeoutOnRedirects Whether the connect timeout is reset when a redirect occurs.
   */
  public CronetDataSource(CronetEngine cronetEngine, Executor executor,
      Predicate<String> contentTypePredicate, TransferListener listener, int connectTimeoutMs,
      int readTimeoutMs, boolean resetTimeoutOnRedirects) {
    this(cronetEngine, executor, contentTypePredicate, listener, connectTimeoutMs,
        readTimeoutMs, resetTimeoutOnRedirects, new SystemClock());
  }

  /* package */ CronetDataSource(CronetEngine cronetEngine, Executor executor,
      Predicate<String> contentTypePredicate, TransferListener listener, int connectTimeoutMs,
      int readTimeoutMs, boolean resetTimeoutOnRedirects, Clock clock) {
    this.cronetEngine = Assertions.checkNotNull(cronetEngine);
    this.executor = Assertions.checkNotNull(executor);
    this.contentTypePredicate = contentTypePredicate;
    this.listener = listener;
    this.connectTimeoutMs = connectTimeoutMs;
    this.readTimeoutMs = readTimeoutMs;
    this.resetTimeoutOnRedirects = resetTimeoutOnRedirects;
    this.clock = Assertions.checkNotNull(clock);
    requestProperties = new HashMap<>();
    operation = new ConditionVariable();
  }

  // HttpDataSource implementation.

  @Override
  public void setRequestProperty(String name, String value) {
    synchronized (requestProperties) {
      requestProperties.put(name, value);
    }
  }

  @Override
  public void clearRequestProperty(String name) {
    synchronized (requestProperties) {
      requestProperties.remove(name);
    }
  }

  @Override
  public void clearAllRequestProperties() {
    synchronized (requestProperties) {
      requestProperties.clear();
    }
  }

  @Override
  public Map<String, List<String>> getResponseHeaders() {
    return responseInfo == null ? null : responseInfo.getAllHeaders();
  }

  @Override
  public String getUri() {
    return responseInfo == null ? null : responseInfo.getUrl();
  }

  @Override
  public long open(DataSpec dataSpec) throws HttpDataSourceException {
    Assertions.checkNotNull(dataSpec);
    Assertions.checkState(!opened);

    operation.close();
    resetConnectTimeout();
    currentDataSpec = dataSpec;
    currentUrlRequest = buildRequest(dataSpec);
    currentUrlRequest.start();
    boolean requestStarted = blockUntilConnectTimeout();

    if (exception != null) {
      throw new OpenException(exception, currentDataSpec, getStatus(currentUrlRequest));
    } else if (!requestStarted) {
      // The timeout was reached before the connection was opened.
      throw new OpenException(new SocketTimeoutException(), dataSpec, getStatus(currentUrlRequest));
    }

    // Check for a valid response code.
    int responseCode = responseInfo.getHttpStatusCode();
    if (responseCode < 200 || responseCode > 299) {
      throw new InvalidResponseCodeException(responseCode, responseInfo.getAllHeaders(),
          currentDataSpec);
    }

    // Check for a valid content type.
    if (contentTypePredicate != null) {
      List<String> contentTypeHeaders = responseInfo.getAllHeaders().get(CONTENT_TYPE);
      String contentType = isEmpty(contentTypeHeaders) ? null : contentTypeHeaders.get(0);
      if (!contentTypePredicate.evaluate(contentType)) {
        throw new InvalidContentTypeException(contentType, currentDataSpec);
      }
    }

    // If we requested a range starting from a non-zero position and received a 200 rather than a
    // 206, then the server does not support partial requests. We'll need to manually skip to the
    // requested position.
    bytesToSkip = responseCode == 200 && dataSpec.position != 0 ? dataSpec.position : 0;

    // Calculate the content length.
    if (!getIsCompressed(responseInfo)) {
      if (dataSpec.length != C.LENGTH_UNBOUNDED) {
        bytesRemaining = dataSpec.length;
      } else {
        bytesRemaining = getContentLength(responseInfo);
      }
    } else {
      // If the response is compressed then the content length will be that of the compressed data
      // which isn't what we want. Always use the dataSpec length in this case.
      bytesRemaining = currentDataSpec.length;
    }

    opened = true;
    if (listener != null) {
      listener.onTransferStart();
    }

    return bytesRemaining;
  }

  @Override
  public int read(byte[] buffer, int offset, int readLength) throws HttpDataSourceException {
    Assertions.checkState(opened);

    if (readLength == 0) {
      return 0;
    } else if (bytesRemaining == 0) {
      return C.RESULT_END_OF_INPUT;
    }

    if (readBuffer == null) {
      readBuffer = ByteBuffer.allocateDirect(READ_BUFFER_SIZE_BYTES);
      readBuffer.limit(0);
    }
    while (!readBuffer.hasRemaining()) {
      // Fill readBuffer with more data from Cronet.
      operation.close();
      readBuffer.clear();
      currentUrlRequest.read(readBuffer);
      if (!operation.block(readTimeoutMs)) {
        // We're timing out, but since the operation is still ongoing we'll need to replace
        // readBuffer to avoid the possibility of it being written to by this operation during a
        // subsequent request.
        readBuffer = null;
        throw new HttpDataSourceException(
            new SocketTimeoutException(), currentDataSpec, HttpDataSourceException.TYPE_READ);
      } else if (exception != null) {
        throw new HttpDataSourceException(exception, currentDataSpec,
            HttpDataSourceException.TYPE_READ);
      } else if (finished) {
        return C.RESULT_END_OF_INPUT;
      } else {
        // The operation didn't time out, fail or finish, and therefore data must have been read.
        readBuffer.flip();
        Assertions.checkState(readBuffer.hasRemaining());
        if (bytesToSkip > 0) {
          int bytesSkipped = (int) Math.min(readBuffer.remaining(), bytesToSkip);
          readBuffer.position(readBuffer.position() + bytesSkipped);
          bytesToSkip -= bytesSkipped;
        }
      }
    }

    int bytesRead = Math.min(readBuffer.remaining(), readLength);
    readBuffer.get(buffer, offset, bytesRead);

    if (bytesRemaining != C.LENGTH_UNBOUNDED) {
      bytesRemaining -= bytesRead;
    }
    if (listener != null) {
      listener.onBytesTransferred(bytesRead);
    }
    return bytesRead;
  }

  @Override
  public synchronized void close() {
    if (currentUrlRequest != null) {
      currentUrlRequest.cancel();
      currentUrlRequest = null;
    }
    if (readBuffer != null) {
      readBuffer.limit(0);
    }
    currentDataSpec = null;
    responseInfo = null;
    exception = null;
    finished = false;
    if (opened) {
      opened = false;
      if (listener != null) {
        listener.onTransferEnd();
      }
    }
  }

  // UrlRequest.Callback implementation

  @Override
  public synchronized void onRedirectReceived(UrlRequest request, UrlResponseInfo info,
      String newLocationUrl) {
    if (request != currentUrlRequest) {
      return;
    }
    if (currentDataSpec.postBody != null) {
      int responseCode = info.getHttpStatusCode();
      // The industry standard is to disregard POST redirects when the status code is 307 or 308.
      // For other redirect response codes the POST request is converted to a GET request and the
      // redirect is followed.
      if (responseCode == 307 || responseCode == 308) {
        exception = new InvalidResponseCodeException(responseCode, info.getAllHeaders(),
            currentDataSpec);
        operation.open();
        return;
      }
    }
    if (resetTimeoutOnRedirects) {
      resetConnectTimeout();
    }
    request.followRedirect();
  }

  @Override
  public synchronized void onResponseStarted(UrlRequest request, UrlResponseInfo info) {
    if (request != currentUrlRequest) {
      return;
    }
    responseInfo = info;
    operation.open();
  }

  @Override
  public synchronized void onReadCompleted(UrlRequest request, UrlResponseInfo info,
      ByteBuffer buffer) {
    if (request != currentUrlRequest) {
      return;
    }
    operation.open();
  }

  @Override
  public synchronized void onSucceeded(UrlRequest request, UrlResponseInfo info) {
    if (request != currentUrlRequest) {
      return;
    }
    finished = true;
    operation.open();
  }

  @Override
  public synchronized void onFailed(UrlRequest request, UrlResponseInfo info,
      CronetException error) {
    if (request != currentUrlRequest) {
      return;
    }
    if (error instanceof NetworkException
        && ((NetworkException) error).getErrorCode()
            == NetworkException.ERROR_HOSTNAME_NOT_RESOLVED) {
      exception = new UnknownHostException();
    } else {
      exception = error;
    }
    operation.open();
  }

  // Internal methods.

  private UrlRequest buildRequest(DataSpec dataSpec) throws OpenException {
    UrlRequest.Builder requestBuilder = cronetEngine.newUrlRequestBuilder(dataSpec.uri.toString(),
        this, executor);
    // Set the headers.
    synchronized (requestProperties) {
      if (dataSpec.postBody != null && dataSpec.postBody.length != 0
          && !requestProperties.containsKey(CONTENT_TYPE)) {
        throw new OpenException("POST request with non-empty body must set Content-Type", dataSpec,
            Status.IDLE);
      }
      for (Entry<String, String> headerEntry : requestProperties.entrySet()) {
        requestBuilder.addHeader(headerEntry.getKey(), headerEntry.getValue());
      }
    }
    // Set the Range header.
    if (currentDataSpec.position != 0 || currentDataSpec.length != C.LENGTH_UNBOUNDED) {
      StringBuilder rangeValue = new StringBuilder();
      rangeValue.append("bytes=");
      rangeValue.append(currentDataSpec.position);
      rangeValue.append("-");
      if (currentDataSpec.length != C.LENGTH_UNBOUNDED) {
        rangeValue.append(currentDataSpec.position + currentDataSpec.length - 1);
      }
      requestBuilder.addHeader("Range", rangeValue.toString());
    }
    // Set the method and (if non-empty) the body.
    if (dataSpec.postBody != null) {
      requestBuilder.setHttpMethod("POST");
      if (dataSpec.postBody.length != 0) {
        requestBuilder.setUploadDataProvider(new ByteArrayUploadDataProvider(dataSpec.postBody),
            executor);
      }
    }
    return requestBuilder.build();
  }

  private boolean blockUntilConnectTimeout() {
    long now = clock.elapsedRealtime();
    boolean opened = false;
    while (!opened && now < currentConnectTimeoutMs) {
      opened = operation.block(currentConnectTimeoutMs - now + 5 /* fudge factor */);
      now = clock.elapsedRealtime();
    }
    return opened;
  }

  private void resetConnectTimeout() {
    currentConnectTimeoutMs = clock.elapsedRealtime() + connectTimeoutMs;
  }

  private static boolean getIsCompressed(UrlResponseInfo info) {
    for (Map.Entry<String, String> entry : info.getAllHeadersAsList()) {
      if (entry.getKey().equalsIgnoreCase("Content-Encoding")) {
        return !entry.getValue().equalsIgnoreCase("identity");
      }
    }
    return false;
  }

  private static long getContentLength(UrlResponseInfo info) {
    long contentLength = C.LENGTH_UNBOUNDED;
    Map<String, List<String>> headers = info.getAllHeaders();
    List<String> contentLengthHeaders = headers.get("Content-Length");
    String contentLengthHeader = null;
    if (!isEmpty(contentLengthHeaders)) {
      contentLengthHeader = contentLengthHeaders.get(0);
      if (!TextUtils.isEmpty(contentLengthHeader)) {
        try {
          contentLength = Long.parseLong(contentLengthHeader);
        } catch (NumberFormatException e) {
          Log.e(TAG, "Unexpected Content-Length [" + contentLengthHeader + "]");
        }
      }
    }
    List<String> contentRangeHeaders = headers.get("Content-Range");
    if (!isEmpty(contentRangeHeaders)) {
      String contentRangeHeader = contentRangeHeaders.get(0);
      Matcher matcher = CONTENT_RANGE_HEADER_PATTERN.matcher(contentRangeHeader);
      if (matcher.find()) {
        try {
          long contentLengthFromRange =
              Long.parseLong(matcher.group(2)) - Long.parseLong(matcher.group(1)) + 1;
          if (contentLength < 0) {
            // Some proxy servers strip the Content-Length header. Fall back to the length
            // calculated here in this case.
            contentLength = contentLengthFromRange;
          } else if (contentLength != contentLengthFromRange) {
            // If there is a discrepancy between the Content-Length and Content-Range headers,
            // assume the one with the larger value is correct. We have seen cases where carrier
            // change one of them to reduce the size of a request, but it is unlikely anybody
            // would increase it.
            Log.w(TAG, "Inconsistent headers [" + contentLengthHeader + "] [" + contentRangeHeader
                + "]");
            contentLength = Math.max(contentLength, contentLengthFromRange);
          }
        } catch (NumberFormatException e) {
          Log.e(TAG, "Unexpected Content-Range [" + contentRangeHeader + "]");
        }
      }
    }
    return contentLength;
  }

  private static int getStatus(UrlRequest request) {
    final ConditionVariable conditionVariable = new ConditionVariable();
    final int[] statusHolder = new int[1];
    request.getStatus(new UrlRequest.StatusListener() {
      @Override
      public void onStatus(int status) {
        statusHolder[0] = status;
        conditionVariable.open();
      }
    });
    conditionVariable.block();
    return statusHolder[0];
  }

  private static boolean isEmpty(List<?> list) {
    return list == null || list.isEmpty();
  }

}
