Copy folders containing architecture specific .so files here.
