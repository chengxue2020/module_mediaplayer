# Cast demo

This app demonstrates integration with Google Cast, as well as switching between
Google Cast and local playback using ExoPlayer.

See the [demos README](../README.md) for instructions on how to build and run
this demo.
