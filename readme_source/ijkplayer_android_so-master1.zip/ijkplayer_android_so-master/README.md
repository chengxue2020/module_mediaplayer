# ijkplayer_android_so
已编译完成支持https,支持各种视频格式，支持m3u8(AES-128普通加密)的ijkplayer库
