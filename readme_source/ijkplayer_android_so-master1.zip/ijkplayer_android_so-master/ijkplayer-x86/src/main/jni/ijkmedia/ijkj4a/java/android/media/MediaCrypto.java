package android.media;

@Hide
@MinApi(16)
public class MediaCrypto {
}
