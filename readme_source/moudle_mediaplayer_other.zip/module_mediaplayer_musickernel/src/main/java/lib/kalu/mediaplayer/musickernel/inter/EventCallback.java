package lib.kalu.mediaplayer.musickernel.inter;


public interface EventCallback<T> {
    void onEvent(T t);
}
