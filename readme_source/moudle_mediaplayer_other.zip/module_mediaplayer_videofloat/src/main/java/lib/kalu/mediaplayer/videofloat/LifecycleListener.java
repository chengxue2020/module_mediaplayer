package lib.kalu.mediaplayer.videofloat;


interface LifecycleListener {

    void onShow();

    void onHide();

    void onPostHide();
}
